package com.example.tripplanner;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FifthActivity extends AppCompatActivity {

    // variables for database that carried over
    private EditText tripStartTxt;
    private EditText tripEndTxt;
    private EditText tripDateTxt;
    private EditText tripMethodTxt;

    private Button addTripBtn;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);

        tripStartTxt = findViewById(R.id.idEditTripStartLocation);
        tripEndTxt = findViewById(R.id.idEditTripEndLocation);
        tripDateTxt = findViewById(R.id.idEditTripDate);
        tripMethodTxt = findViewById(R.id.idEditTripMethodTransport);

        dbHandler = new DBHandler(FifthActivity.this);

        addTripBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String tripStart = tripStartTxt.getText().toString();
                String tripEnd = tripEndTxt.getText().toString();
                String tripDate = tripDateTxt.getText().toString();
                String tripMethod = tripMethodTxt.getText().toString();

                // make sure none of the fields are empty
                if (tripStart.isEmpty() || tripEnd.isEmpty() || tripDate.isEmpty() || tripMethod.isEmpty()){
                    Toast.makeText(FifthActivity.this, "Please make sure no fields are empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                // call on method created to add a new trip to the database
                dbHandler.addNewTrip(tripStart, tripEnd, tripDate, tripMethod);

                // display message confirming addition to database
                Toast.makeText(FifthActivity.this, "Trip added!", Toast.LENGTH_SHORT).show();

                // make the fields empty
                tripStartTxt.setText("");
                tripEndTxt.setText("");
                tripDateTxt.setText("");
                tripMethodTxt.setText("");
            }
        });
    }
}
