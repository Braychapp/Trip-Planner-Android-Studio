package com.example.tripplanner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.widget.TextView;
import android.util.Log;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private TextView startText;
    private String username = "";
    private ArrayList<Trip> tripsList;
    private String[] destinations = {"Toronto", "Ottawa", "New York", "Vancouver", "Miami", "Los Angeles", "San Francisco", "Las Vegas", "Paris", "London", "Rome", "Athens", "Amsterdam", "Berlin", "Barcelona", "Madrid", "Tokyo", "Kyoto", "Osaka", "Seoul", "Bangkok", "Phuket", "Bali", "Sydney", "Melbourne", "Perth", "Auckland", "Queenstown", "Cape Town", "Johannesburg", "Nairobi", "Dubai", "Abu Dhabi", "Doha", "Mumbai", "New Delhi", "Bangalore", "Singapore", "Kuala Lumpur", "Jakarta", "Hong Kong", "Macau", "Taipei", "Shanghai", "Beijing", "Moscow", "St. Petersburg"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i(Global.MTAG, "onCreate: MainActivity started");

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        startText = findViewById(R.id.username);
        username = "";
        startText.setText(username);

        tripsList = new ArrayList<>();

        Random random = new Random();

        for (int i = 0; i < 5; i++) {
            String start = destinations[random.nextInt(destinations.length)];
            String end = destinations[random.nextInt(destinations.length)];
            tripsList.add(new Trip(start, end));
        }

        mAdapter = new TripAdapter(tripsList);
        recyclerView.setAdapter(mAdapter);
    }
}
