package com.example.tripplanner;

public class Global {
    public static String startLocation;
    public static String endLocation;
    public static String date;
    public static String MTAG = "MainActivity";

    public static String username = "";

    public static String methodTransport_To;
    public static String methodTransport_From;



}
