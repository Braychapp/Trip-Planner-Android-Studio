package com.example.tripplanner;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private Button continueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date);

        calendarView = findViewById(R.id.calendarView);
        continueButton = findViewById(R.id.button);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String selectedDate = dayOfMonth + "/" + (month+1) + "/" + year;
                Global.date = selectedDate;
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Set the Global.date variable to the selected date on the calendarView widget
                long selectedDateInMilliseconds = calendarView.getDate();
                Global.date = formatDate(selectedDateInMilliseconds);

                // Start the SecondActivity
                Intent intent = new Intent(DateActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });
    }

    // Method to format a date from milliseconds to "dd/MM/yyyy" format
    private String formatDate(long milliseconds) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return sdf.format(new Date(milliseconds));
    }
}
